package ssh.homework.service;

import java.util.List;

import ssh.homework.domain.StudentWorkbook;

public interface UtilService {
	public void sortStudentWorkbook(List<StudentWorkbook> list);//对学生作业按习题类别排序


}
