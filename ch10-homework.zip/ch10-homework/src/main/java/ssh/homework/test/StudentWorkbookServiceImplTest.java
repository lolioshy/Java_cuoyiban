package ssh.homework.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.domain.Exercise;
import ssh.homework.domain.Student;
import ssh.homework.domain.StudentInfo;
import ssh.homework.domain.StudentWorkbook;
import ssh.homework.domain.Workbook;
import ssh.homework.service.StudentWorkbookService;
import ssh.homework.tag.PageModel;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:applicationContext.xml"})
public class StudentWorkbookServiceImplTest {
	
	@Autowired
	private StudentWorkbookService studentWorkbookService;

	//@Test
	public void testFindStudentWorkbookById() {
		 StudentWorkbook book=studentWorkbookService.findStudentWorkbookById(13);
		 System.out.println(book.getStudent().getUsername());
	}

	//@Test
	public void testFindStudentWorkbook() {
		StudentWorkbook studentWorkbook=new StudentWorkbook();
		Student student=new Student();
		
		student.setId(11);
		Workbook workbook=new Workbook();
		workbook.setId(2);
		studentWorkbook.setWorkbook(workbook);
		studentWorkbook.setStudent(student);
		PageModel pageModel=new PageModel();
		List<StudentWorkbook> s=studentWorkbookService.findStudentWorkbook(studentWorkbook, pageModel);
		System.out.println(s.size());
		
	}

	//@Test
	public void testRemoveStudentWorkbookById() {
		studentWorkbookService.removeStudentWorkbookById(14);
	}

	//@Test
	public void testModifyStudentWorkbook() {
		StudentWorkbook studentWorkbook=studentWorkbookService.findStudentWorkbookById(14);
		studentWorkbook.setStudentAnswer("aaaaaabcefd");
		studentWorkbookService.modifyStudentWorkbook(studentWorkbook);
	}

	//@Test
	public void testAddStudentWorkbook() {
		StudentWorkbook studentWorkbook=new StudentWorkbook();
		Student student=new Student();
		student.setId(13);
		Workbook workbook=new Workbook();
		workbook.setId(11);
		Exercise exercise=new Exercise();
		exercise.setId(11);
		studentWorkbook.setExercise(exercise);
		studentWorkbook.setStudent(student);
		studentWorkbook.setWorkbook(workbook);
		studentWorkbook.setGrade(5);
		studentWorkbookService.addStudentWorkbook(studentWorkbook);
		
		
	}
	@Test
	public void findStudentInfoGroupByStudentIdByWorkbookId() {
		List<StudentInfo> sts=studentWorkbookService.findStudentInfoGroupByStudentIdByWorkbookId(18);
		for (int i=0;i<sts.size();i++)
		System.out.println(sts.get(i).getStudent().getUsername());
	}

}
