package ssh.homework.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ssh.homework.domain.Teacher;
import ssh.homework.domain.Workbook;
import ssh.homework.service.WorkbookService;
import ssh.homework.tag.PageModel;

import java.util.List;

import static org.junit.Assert.assertEquals;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:applicationContext.xml"})
public class WorkbookServiceImplTest {
	@Autowired
	WorkbookService workbookService;
	//@Test
	public void testFindWorkbook() {
		Workbook workbook=new Workbook();
		PageModel pageModel=new PageModel();
		//Map params=new HashMap();
//		params.put("workbook",workbook);
//		params.put("pageModel",pageModel);
		Teacher teacher=new Teacher();
		teacher.setId(2);
		workbook.setTeacher(teacher);
    	List workbooks=workbookService.findWorkbook(workbook, pageModel);
		System.out.println(workbooks.size());
	}
	//@Test
	public void findWorkbookByTitle() {
		Workbook workbook=new Workbook();
		workbook.setTitle("java");
		List<Workbook> books=workbookService.findWorkbookByTitle("java程序设计第五次",5);
		System.out.println(books.size());
		
	}
	//@Test
	public void findWorkbookByCourseIdAndClazzIdAndWflagAndTerm() {
		List<Workbook> books=workbookService.findWorkbookByCourseIdAndClazzIdAndWflagAndTerm(
				13,10, 12, "2018-2019-1");
		System.out.println(books.size());
		
	}
	@Test
	public void findTerm() {
		List<String> terms=workbookService.findTerm();
		System.out.println(terms.size());
		assertEquals(terms.size(),7);//原来的数字是1.测试时进行了修改

	}

}
