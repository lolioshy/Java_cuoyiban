package ssh.homework.test;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.dao.WorkbookDao;
import ssh.homework.domain.Clazz;
import ssh.homework.domain.Course;
import ssh.homework.domain.Teacher;
import ssh.homework.domain.Workbook;
import ssh.homework.tag.PageModel;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:applicationContext.xml"})
public class WorkbookDaoTest {
	@Autowired
	WorkbookDao workbookDao;

    //@Test
    public void testSelectCount() {
    	Workbook workbook=new Workbook();
		Clazz clazz=new Clazz();
		Course course=new Course();
		Teacher teacher=new Teacher();
	
		clazz.setId(2);
		course.setId(17);
		teacher.setId(12);
		workbook.setClazz(clazz);
		//workbook.setCourse(course);
		//workbook.setTeacher(teacher);
		//workbook.setFlag('3');
		Map params=new HashMap();
		//System.out.println(workbook.getFlag());
		params.put("workbook",workbook);
		int count=workbookDao.count(params);
		System.out.println(count);
    }
	
	//@Test
	public void testSelectById() {
		Workbook workbook=new Workbook();
		workbook.setId(2);
		workbook=workbookDao.selectById(3);
		System.out.println(workbook.getWflag());
		
	}
	//@Test
	public void testSelectByPage() {
		Workbook workbook=new Workbook();
		Clazz clazz=new Clazz();
		Course course=new Course();
		Teacher teacher=new Teacher();
	
		clazz.setId(2);
		//course.setId(17);
		//teacher.setId(12);
		workbook.setClazz(clazz);
		//workbook.setCourse(course);
		//workbook.setTeacher(teacher);
		//workbook.setFlag('3');
		
		Map params=new HashMap();
		System.out.println(workbook.getWflag());
		PageModel pageModel=new PageModel();
		pageModel.setPageSize(10);
		params.put("workbook",workbook);
		List<Workbook> workbooks=workbookDao.selectByPage(params);
		for(int i=0;i<workbooks.size();i++)
		System.out.println(workbooks.get(i).getWflag());
	}
	
	//@Test
	public void testAddWorkbook() {
		Workbook workbook=new Workbook();
		Clazz clazz=new Clazz();
		Course course=new Course();
		Teacher teacher=new Teacher();
		clazz.setId(5);
		course.setId(4);
		
		teacher.setId(5);
		workbook.setClazz(clazz);
		workbook.setCourse(course);
		workbook.setTeacher(teacher);
		workbook.setWflag("0");
		workbook.setTerm("2017-2018-1");
		workbook.setTitle("java程序设计第二次作业");
		workbook.setCreateDate(new Date());
		workbookDao.save(workbook);
		
		
	}
	
	//@Test
	public void selectWorkbooksByClazzId() {
		List<Workbook> workbooks=workbookDao.selectWorkbooksByClazzId(8);
		System.out.println(workbooks.size());
	}
	//@Test
	public void deleteWorkbookById() {
		workbookDao.deleteById(5);
	}
	

}
