package ssh.homework.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.dao.ExerciseDao;
import ssh.homework.domain.Course;
import ssh.homework.domain.Exercise;
import ssh.homework.domain.Teacher;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:applicationContext.xml"})
public class ExerciseDaoTest {
	@Autowired
	ExerciseDao exerciseDao; 

//	@Test
	public void testSave() {
		Exercise exercise=new Exercise();
		Course course=new Course();
		course.setId(7);
		Teacher teacher=new Teacher();
		teacher.setId(2);
		exercise.setKind("选择题");
		exercise.setContent("计算机某一年是否是闰年16");
		exercise.setChapter("2");
		exercise.setAnswer("b");
		exercise.setCourse(course);
		exercise.setTeacher(teacher);
		exerciseDao.save(exercise);
		
	}
	//@Test
	public void testDeleteById() {
		exerciseDao.deleteById(10);
	}
	@Test
	public void update() {
		Exercise exercise=new Exercise();
		exercise.setId(31);
		exercise.setKind("简答题");
		exercise.setContent("计算机某一年是否是闰年15");
		exercise.setChapter("3");
		exercise.setAnswer("b");
		Course course=new Course();
		course.setId(2);
		Teacher teacher=new Teacher();
		teacher.setId(2);
		exercise.setCourse(course);
		exercise.setTeacher(teacher);
		exerciseDao.update(exercise);
		
	}
	//@Test
	public  void selectById() {
		Exercise exercise=exerciseDao.selectById(1);
		System.out.println(exercise.getTeacher().getUsername()+" "+exercise.getCourse().getCname());
		
	}
	//@Test
	public void selectByPage() {
		Map map=new HashMap();
		Exercise exercise=new Exercise();
		//exercise.setId(1);
		//exercise.setKind("1");
		//exercise.setChapter("3");
		map.put("exercise",exercise);
		List list=exerciseDao.selectByPage(map);
		for(int i=0;i<list.size();i++) {
			exercise=(Exercise)list.get(i);
			System.out.println(exercise.getChapter());
		}
		
		
	}
	//@Test
	public void count() {
		Map map=new HashMap();
		Exercise exercise=new Exercise();
		Course course=new Course();
		Teacher teacher=new Teacher();
		teacher.setId(22);
		//course.setId(17);
		//exercise.setKind("1");
		exercise.setTeacher(teacher);
		map.put("exercise",exercise);
		Integer in=exerciseDao.count(map);
		System.out.println(in);
		
		
	}
}
