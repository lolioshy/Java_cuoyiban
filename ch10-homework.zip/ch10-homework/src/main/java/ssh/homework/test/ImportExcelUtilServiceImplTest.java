package ssh.homework.test;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.service.ImportExcelUtilService;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class ImportExcelUtilServiceImplTest {
	@Autowired
	ImportExcelUtilService importExcelUtilService;

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testGetBankListByExcel() throws Exception {
		InputStream in=new FileInputStream("f:\\Book1.xlsx");

		String file="f:\\Book1.xlsx";
		
		
		List<List<Object>> list=importExcelUtilService.getBankListByExcel(in, file);
		System.out.println(list.size());
	}

}
