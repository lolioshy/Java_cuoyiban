package ssh.homework.test;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.*;
import ssh.homework.dao.CourseDao;
import ssh.homework.domain.Course;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
//CourseDao类测试类
public class CourseDaoTest {
	@Autowired
	CourseDao courseDao;
//测试根据id查询课程selectById()方法
	@Test
	public void testSelectById() {
		Course course=courseDao.selectById(10);
		assertNotNull("查询失败",course);
		System.out.println(course.getCname());
	}
//测试根据id删除deleteByIdz()方法 
	//@Test
	public void testDeleteById() {
		courseDao.deleteById(5);
	}
//测试selectByPage方法
	@Test
	public void testSelectByPage() {
		Map<String,Object> map=new HashMap<String,Object>();
		Course course=new Course();
		course.setCname("设计");
		map.put("course",course);
		List<Course> list=courseDao.selectByPage(map);
		System.out.println(list.size());
	}
//测试count()方法 
	//@Test
	public void testCount() {
		Map<String,Object> map=new HashMap<String,Object>();
		Course course=new Course();
		course.setCname("VC程序设计");
		map.put("course",course);
	
		System.out.println(courseDao.count(map));
	}
//测试save()方法
	//@Test
	public void testSave() {
		Course course=new Course();
		course.setCname("VB程序设计");
		courseDao.save(course);
		
	}
//测试update方法 
	//@Test
	public void testUpdate() {
		Course course=new Course();
		course.setCname("Vc程序设计");
		course.setId(7);
		courseDao.update(course);
	}

}
