package ssh.homework.test;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.dao.TeacherDao;
import ssh.homework.domain.Teacher;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class TeacherDaoTest {
	@Autowired  
	TeacherDao teacherDao;






	//@Test
	public void testSelectByLoginnameAndPassword() {
		Teacher tea=teacherDao.selectByLoginnameAndPassword("admin1","12" );
		System.out.println(tea.getLoginname());
	}
	@Test
	public void selectById() {
		Teacher tea=teacherDao.selectById(2);
		System.out.println(tea.getUsername());
	}
	//@Test
	public void deleteById() {
		teacherDao.deleteById(17);
	};
	//@Test
	public void save() {
		Teacher teacher=new Teacher();
		teacher.setLoginname("login2");
		teacher.setPassword("password2");
		teacher.setUsername("李权");
		teacher.setRole("1");
		teacherDao.save(teacher);
		
	};
	//@Test
	public void count() {
		Map map=new HashMap();
		Teacher teacher=new Teacher();
		teacher.setLoginname("admin");
		map.put("tea",teacher);
		Integer n=teacherDao.count(map);
		System.out.println(n);
		
	};
	
	//@Test
	public void selectByPage() {
		Map map=new HashMap();
		Teacher teacher=new Teacher();
		//teacher.setLoginname("admin1");
		teacher.setUsername("张");
		map.put("teacher",teacher);
		List list=teacherDao.selectByPage(map);
		System.out.println(list.size());
		
	}

}
