package ssh.homework.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.dao.ClazzDao;
import ssh.homework.domain.Clazz;
import ssh.homework.domain.Student;
import ssh.homework.domain.Workbook;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:applicationContext.xml"})
public class ClazzDaoTest {
	@Autowired
	ClazzDao clazzDao;
//
//	@Test
	public void testSelectById() {
		Clazz clazz=clazzDao.selectById(11);
		System.out.println(clazz.getCname());
		
	}

//	@Test
	public void testDeleteById() {
		clazzDao.deleteById(11);
	}

	//@Test
	public void testSave() {
		Clazz clazz=new Clazz();
		clazz.setCname("软件1504");
		clazzDao.save(clazz);
	}

	//@Test
	public void testUpdate() {
		Clazz clazz=new Clazz();
		clazz.setId(2);
		clazz.setCname("软件1506");
		clazzDao.update(clazz);;
	}

//	@Test
	public void testSelectByPage() {
		Map map=new HashMap();
		Clazz clazz=new Clazz();
		
		clazz.setCname("网络L183");
		map.put("clazz",clazz);
		List list=clazzDao.selectByPage(map);
		System.out.println(list.size());
	}

//	@Test
	public void testCount() {
		Map map=new HashMap();
		Clazz clazz=new Clazz();
		
		clazz.setCname("网络");
		map.put("clazz",clazz);
		Integer count=clazzDao.count(map);
		System.out.println(count);
	}
//	@Test
	public void selectClazzByIdToMany() {
		Clazz clazz=clazzDao.selectClazzByIdToMany(12);
		List<Workbook> workbooks=clazz.getWorkbooks();
		List<Student> students=clazz.getStudents();
		for(Workbook wk:workbooks) {
			System.out.println(wk.getTitle());
		}
		for(Student st:students) {
			System.out.println(st.getUsername());
		}
		
	}

}
