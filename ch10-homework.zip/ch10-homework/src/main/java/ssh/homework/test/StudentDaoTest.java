package ssh.homework.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.dao.StudentDao;
import ssh.homework.domain.Clazz;
import ssh.homework.domain.Student;
import ssh.homework.domain.StudentInfo;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:applicationContext.xml"})
public class StudentDaoTest {
	@Autowired
	StudentDao studentDao;
	//@Test
	public void selectByLoginnameAndPassword()
	{
		
		System.out.println(studentDao.selectByLoginnameAndPassword("stu1","11").getUsername());
		
	}

	//@Test
	public void testSelectById() {
		Student student=studentDao.selectById(2);
		System.out.println(student.getLoginname());
	}

	//@Test
	public void testDeleteById() {
		studentDao.deleteById(6);
	}

	//@Test
	public void testSelectByPage() {
		Map map=new HashMap();
		Student student=new Student();
		Clazz clazz=new Clazz();
		clazz.setId(5);
		student.setLoginname("honghong");
//		student.setPassword("11");
		//student.setUsername("李丽");
		student.setClazz(clazz);
		map.put("student",student);
		List list=studentDao.selectByPage(map);
		for(int i=0;i<list.size();i++)
		System.out.println(((Student)list.get(i)).getClazz().getCname());
	}

	//@Test
	public void testCount() {
		Map map=new HashMap();
		Student student=new Student();
		Clazz clazz=new Clazz();
		clazz.setId(2);
//		student.setLoginname("stu5");
//		student.setPassword("11");
//		student.setUsername("李丽3");
		student.setClazz(clazz);
		map.put("student",student);
		System.out.println(studentDao.count(map));
		
	}

	//@Test
	public void testSave() {
		Student student=new Student();
		Clazz clazz=new Clazz();
		clazz.setId(6);
		student.setLoginname("stu9");
		student.setPassword("11");
		student.setUsername("李丽7");
		student.setClazz(clazz);
		studentDao.save(student);
	}

//	//@Test
//	public void testUpdate() {
//		Student student=new Student();
//		student.setId(6);
//		Clazz clazz=new Clazz();
//		clazz.setId(9);
//		student.setLoginname("stu8");
//		student.setPassword("111");
//		student.setUsername("李丽8");
//		student.setClazz(clazz);
//		studentDao.update(student);
//	}

}
