package ssh.homework.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.domain.Teacher;
import ssh.homework.service.TeacherService;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class HomeworkServiceImplTest {
	@Autowired
	TeacherService homeworkService;

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testLogin() {
		Teacher teacher=homeworkService.login("admin","11");
		System.out.println(teacher.getLoginname());
	}

}
