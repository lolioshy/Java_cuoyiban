package ssh.homework.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.domain.Course;
import ssh.homework.service.CourseService;
import ssh.homework.tag.PageModel;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:applicationContext.xml"})
public class CourseServiceImplTest {
	@Autowired
	CourseService courseService;

	@Test
	public void testFindCourse() {
		Course course=new Course();
		course.setCname("java");
		PageModel pageModel=new PageModel();
		List list=courseService.findCourse(course, pageModel);
		System.out.println(list.size());

		
	}

	//@Test
	public void testFindAllCourse() {
		List list=courseService.findAllCourse();
		System.out.println(list.size());
	}

}
