package ssh.homework.test;



import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.domain.Clazz;
import ssh.homework.domain.Student;
import ssh.homework.service.StudentService;
import ssh.homework.tag.PageModel;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class StudentServiceImplTest {
	@Autowired
	StudentService studentService;

	//@Test
	public void testFindStudent() {
		Student student=new Student();
		student.setUsername("莉莉");
		List list=studentService.findStudent(student, new PageModel());
		//PageModel page=(PageModel)list.get(0);
		System.out.println(list.size());
		
		
	}
	@Test
	public void testSaveStudent() {
		Student student=new Student();
		Clazz clazz=new Clazz();
		clazz.setId(6);
		student.setLoginname("stu10");
		student.setPassword("11");
		student.setUsername("李丽7");
		student.setClazz(clazz);
		studentService.addStudent(student);
	}

}
