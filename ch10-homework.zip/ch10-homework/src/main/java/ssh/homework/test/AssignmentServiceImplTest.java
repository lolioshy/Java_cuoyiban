package ssh.homework.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.domain.Assignment;
import ssh.homework.domain.Exercise;
import ssh.homework.domain.Workbook;
import ssh.homework.service.AssignmentService;
import ssh.homework.tag.PageModel;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class AssignmentServiceImplTest {
	@Autowired
	AssignmentService assignmentService;

	//@Test
	public void testFindAssignmentById() {
		Assignment assignment=assignmentService.findAssignmentById(5);
		System.out.println(assignment.getWorkbook().getTitle());
	}

	//@Test
	public void testFindAssignment() {
		Assignment assignment=new Assignment();
		Workbook workbook=new Workbook();
		workbook.setId(-1);
		assignment.setWorkbook(workbook);
		PageModel pageModel=new PageModel();
		List<Assignment> assignments=assignmentService.findAssignment(assignment, pageModel);
		System.out.println(assignments.size());
	}

	@Test
	public void testRemoveAssignmentById() {
		assignmentService.removeAssignmentById(33);
	}

	//@Test
	public void testModifyAssignment() {
		Assignment assignment=new Assignment();
		assignment.setId(3);
		Exercise exercise=new Exercise();
		exercise.setId(17);
		Workbook workbook=new Workbook();
		workbook.setId(2);
		assignment.setExercise(exercise);
		assignment.setWorkbook(workbook);
		assignmentService.modifyAssignment(assignment);
	}
//
	//@Test
	public void testAddAssignment() {
		Assignment assignment=new Assignment();
		Exercise exercise=new Exercise();
		exercise.setId(23);
		Workbook workbook=new Workbook();
		workbook.setId(1);
		assignment.setExercise(exercise);
		assignment.setWorkbook(workbook);
		assignmentService.addAssignment(assignment);
	}

}
