package ssh.homework.test;

import java.util.Iterator;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ssh.homework.domain.Course;
import ssh.homework.domain.Exercise;
import ssh.homework.domain.ExerciseInfo;
import ssh.homework.domain.Workbook;
import ssh.homework.service.ExerciseService;
import ssh.homework.tag.PageModel;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:applicationContext.xml"})
public class ExerciseServiceImplTest {
	@Autowired
	ExerciseService exerciseService;

	//@Test
	public void testFindExercise() {
		Exercise exercise=new Exercise();
		PageModel pageModel=new PageModel();
		pageModel.setPageSize(100);
		
		List<Exercise> list=exerciseService.findExercise(exercise, pageModel);
		for(int i=0;i<list.size();i++) {
			exercise=(Exercise)list.get(i);
			System.out.println(exercise.getKind());}
	}
	//@Test
	public void testFindByNotInWorkbookIdAndByCourseId() {
		Workbook workbook=new Workbook();
		PageModel pageModel=new PageModel();
		workbook.setId(1);
		Course course=new Course();
		course.setId(1);
		workbook.setCourse(course);
		
		List<Exercise> list=exerciseService.findByNotInWorkbookIdAndByCourseId(workbook,pageModel,"not in");
		for(int i=0;i<list.size();i++) {
			Exercise exercise=(Exercise)list.get(i);
			System.out.println(exercise.getChapter());
		}
	}
	@Test
	public void testFindExerciseByWorkbookId() {
		List<ExerciseInfo> list=exerciseService.findExerciseInfoByWorkbookId(9);
		Iterator<ExerciseInfo> it=list.iterator();
		while(it.hasNext()) {
			ExerciseInfo exer=it.next();
			System.out.println(exer.getExercise().getContent()+" "+exer.getCount());
		}
		

		
	}

}
